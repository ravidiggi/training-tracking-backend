package com.cozentus.trainingtracking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cozentus.trainingtracking.model.Topic;

import java.util.List;

public interface TopicRepository extends JpaRepository<Topic, Integer> {

	List<Topic> findByCourseId(int courseId);

	@Modifying
	@Query("UPDATE Topic SET topicPercentageCompleted=:topicPercentageCompleted where topicId=:topicId")
	void updateTopicPercentageCompleted(Integer topicPercentageCompleted, Integer topicId);
}
