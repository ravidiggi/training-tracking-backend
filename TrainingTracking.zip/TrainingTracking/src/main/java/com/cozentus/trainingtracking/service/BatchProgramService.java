package com.cozentus.trainingtracking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Program;
import com.cozentus.trainingtracking.repository.BatchProgramRepository;

import java.util.List;


@Service
public class BatchProgramService {
	
	@Autowired
	private BatchProgramRepository batchProgramRepository;
	
	
	public List<Program> getByBtachId(Integer batchId){
		List<Program> programs=batchProgramRepository.findByBatchId(batchId);
		
		return programs;
		
	}
	
	
	
	

}
