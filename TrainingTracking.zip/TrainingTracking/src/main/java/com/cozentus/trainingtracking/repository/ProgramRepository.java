package com.cozentus.trainingtracking.repository;


import org.springframework.data.repository.CrudRepository;

import com.cozentus.trainingtracking.model.Program;


public interface ProgramRepository extends CrudRepository<Program, Integer> {

}
