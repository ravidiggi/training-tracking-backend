package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.service.CourseService;

@RestController
@RequestMapping("/course")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class CourseRestController {
	
	@Autowired
	private CourseService courseService;

	@GetMapping("/show/all")
	public ResponseEntity<List<Course>> getAllCourses() {
		return ResponseEntity.ok(courseService.listOfCourses());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Course>> getCourseById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(courseService.findCourseById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Course> addCourse(@RequestBody Course course) {
		return ResponseEntity.ok(courseService.saveCourse(course));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Course> updateCourse(@RequestBody Course course, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(courseService.updateCourse(course, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteCourseById(@RequestBody Course course, @PathVariable("id") Integer id) {
		courseService.deleteCourseById(id);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/show/program/{id}")
	public ResponseEntity<List<Course>> getCoursesByProgramId(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(courseService.getCoursesByProgramId(id));
	}

}
