package com.cozentus.trainingtracking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cozentus.trainingtracking.model.BatchProgram;
import com.cozentus.trainingtracking.model.Program;


public interface BatchProgramRepository extends JpaRepository<BatchProgram, Integer> {
	List<Program> findByBatchId(Integer batchId);
}
