package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cozentus.trainingtracking.utillity.FileUploadUtility;
import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.model.Topic;
import com.cozentus.trainingtracking.service.TopicService;

@RestController
@RequestMapping("/topic")

public class TopicRestController {
	
	@Autowired
	private TopicService topicService;
	
	@Autowired
	private FileUploadUtility fileUploadUtility;


	@GetMapping("/show/all")
	public ResponseEntity<List<Topic>> getAllTopics() {
		return ResponseEntity.ok(topicService.getAllTopics());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Topic>> getTopicById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(topicService.getTopicById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Topic> addTopic(@RequestBody Topic course) {
		return ResponseEntity.ok(topicService.addTopic(course));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Topic> updateTopic(@RequestBody Topic course, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(topicService.updateTopic(course, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteTopicById(@RequestBody Course course, @PathVariable("id") Integer id) {
		topicService.deleteTopic(id);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/show/course/{id}")
	public ResponseEntity<List<Topic>> getTopicByCourseId(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(topicService.getTopicByCourseId(id));
	}
	
	@PostMapping("/upload")
	public ResponseEntity<String> fileUpload(@RequestParam("file") MultipartFile file) {
		System.out.println(file.getContentType());
		System.out.println(file.getName());
		System.out.println(file.getOriginalFilename());
		if (file.isEmpty()) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Please select a proper format");
		}
		if (fileUploadUtility.uploadFile(file)) {
			return ResponseEntity.ok(ServletUriComponentsBuilder.fromCurrentContextPath().path("/uploads/")
					.path(file.getOriginalFilename()).toUriString());
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	}
}
