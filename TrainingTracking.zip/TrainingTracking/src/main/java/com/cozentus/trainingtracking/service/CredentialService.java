package com.cozentus.trainingtracking.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cozentus.trainingtracking.model.Credential;
import com.cozentus.trainingtracking.model.Email;
import com.cozentus.trainingtracking.model.Student;
import com.cozentus.trainingtracking.model.Teacher;
import com.cozentus.trainingtracking.repository.CredentialRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CredentialService {
	@Autowired
	private CredentialRepository credentialRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public String getRole(String username) {
    	return credentialRepository.findUserRole(username);
    }

	public void addTeacherCredential(Teacher teacher) {

		Credential credential = new Credential();

		credential.setUserId(teacher.getTeacherEmail());
		credential.setPassword(getBCryptPassword(createPassword(teacher.getTeacherName())));
		credential.setRole("ROLE_TEACHER");
		credential.setUpdatedDate(teacher.getUpdatedDate());
		credential.setUpdatedBy(teacher.getUpdatedBy());
		credential.setCreatedDate(teacher.getCreatedDate());
		credential.setCreatedBy(teacher.getCreatedBy());

		credentialRepository.save(credential);
		
		String role = "Teacher";
		generateEmail(teacher.getTeacherEmail(), teacher.getTeacherName(), role);
	}
	
	public void addStudentCredential(Student student) {

		Credential credential = new Credential();

		credential.setUserId(student.getStudentEmail());
		credential.setPassword(getBCryptPassword(student.getStudentName()));
		credential.setRole("ROLE_STUDENT");
		credential.setUpdatedDate(student.getUpdatedDate());
		credential.setUpdatedBy(student.getUpdatedBy());
		credential.setCreatedDate(student.getCreatedDate());
		credential.setCreatedBy(student.getCreatedBy());

		credentialRepository.save(credential);
		
		String role = "Student";
		generateEmail(student.getStudentEmail(), student.getStudentName(), role);
	}
	
	public void generateEmail(String recipientEmail, String recipientName, String role) {
	    Email email = new Email();
	    email.setTo(recipientEmail);
	    email.setSubject("Your " + role + " Credentials");

	    String message = String.format("Dear %s,\n\n" +
	            "You have been added as %s. Please use the following credentials to log in:\n\n" +
	            "Username: %s\n" +
	            "Password: %s\n\n" +
	            "Thank you,\n" +
	            "Training Tracking App.", recipientName, role, recipientEmail, createPassword(recipientName));

	    email.setMessage(message);
	    emailService.sendEmail(email);
	}

	public String getBCryptPassword(String password) {
		return passwordEncoder.encode(password);
	}

	public String createPassword(String name) {
		String password;
		String names[] = name.split(" ");
		if (names.length >= 2) {
			password = names[1].substring(0, 1) + names[0] + "@123";
		} else {
			password = name + "@123";
		}

		return password;
	}
}
