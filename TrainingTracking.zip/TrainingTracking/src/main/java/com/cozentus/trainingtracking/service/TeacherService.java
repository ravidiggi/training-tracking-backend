package com.cozentus.trainingtracking.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Teacher;
import com.cozentus.trainingtracking.repository.TeacherRepository;

@Service
public class TeacherService {
	@Autowired
	private TeacherRepository teacherRepository;
	
	public List<Teacher> getAllTeachers () {
		return teacherRepository.findAll();
	}
	
	public Optional<Teacher> getTeacherById(Integer id) {
		return teacherRepository.findById(id);
	}
	
	public Teacher addTeacher(Teacher teacher) {
		
		return teacherRepository.save(teacher);
	}
	
	public Teacher updateTeacher(Teacher teacher, Integer id) {
		teacher.setTeacherId(id);
		return teacherRepository.save(teacher);
	}
	
	public void deleteTeacherById (Integer id) {
		teacherRepository.deleteById(id);
	}
	
	public List<Teacher> getTeachersByCourseId(Integer courseId) {
		return teacherRepository.findByCourseId(courseId);
	}
}
