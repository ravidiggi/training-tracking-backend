package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Attendance;
import com.cozentus.trainingtracking.repository.AttendanceRepository;



@Service
public class AttendanceService {

	@Autowired
	private AttendanceRepository attendanceRepository;

	public List<Attendance> listOfAttendances() {
		List<Attendance> attendance_list = (List<Attendance>) this.attendanceRepository.findAll();
		return attendance_list;

	}

	public Attendance addAttendance(Attendance attendance) {
		return attendanceRepository.save(attendance);

	}

	public Attendance updateAttendance(Attendance attendance, Integer attendanceId) {
		attendance.setAttendanceId(attendanceId);
		return attendanceRepository.save(attendance);
	}

	public void deleteAttendanceById(Integer attendanceId) {
		attendanceRepository.deleteById(attendanceId);
	}

	public Optional<Attendance> findByAttendanceId(Integer attendanceId) {
		Optional<Attendance> attendace_by_id = attendanceRepository.findById(attendanceId);
		return attendace_by_id;
	}

	public void addAttendances(List<Attendance> attendances) {
		for (Attendance attendance : attendances) {
			attendanceRepository.save(attendance);
		}
	}

	public void updateAttendances(List<Attendance> attendances) {
        
		for (Attendance attendance : attendances) {
			attendanceRepository.updateAttendances(attendance.getAttendance(), attendance.getStudentId(), attendance.getDate(), attendance.getBatchId(), attendance.getTopicId(), attendance.getTeacherId());
		}
	}

}
