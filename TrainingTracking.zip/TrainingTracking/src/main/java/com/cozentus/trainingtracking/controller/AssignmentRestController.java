package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.EvaluationName;
import com.cozentus.trainingtracking.service.AssignmentService;


@RestController
@RequestMapping("/assignment")
@PreAuthorize("hasAuthority('ROLE_TEACHER')")
public class AssignmentRestController {
	
	@Autowired 
	private AssignmentService assignemntService;
	
	@GetMapping("/all-assignments")
	public ResponseEntity<List<EvaluationName>> getAllAssignments(){
		List<EvaluationName> all_assignments=assignemntService.listOfAssignments();
		return ResponseEntity.ok(all_assignments);
		
		
	}
		
	@PostMapping("/add-assignment")
	public ResponseEntity<EvaluationName> addAssignment(@RequestBody EvaluationName evaluationName) {
		EvaluationName added_assignment=assignemntService.addAssignment(evaluationName);
		
		return ResponseEntity.ok(added_assignment);
	}
	
	@PutMapping("/update-assignment/{evaluationId}")
	public ResponseEntity<EvaluationName> updateAssignment(@RequestBody EvaluationName evaluationName,@PathVariable("evaluationId")Integer evaluationId) {
		EvaluationName updated_assignment =assignemntService.updateAssignment(evaluationName,evaluationId);
		return ResponseEntity.ok(updated_assignment);
		
	}
	
	@DeleteMapping("/delete-assignment/{evaluationId}")

	public ResponseEntity<Void> deleteAssignmentByIds(@PathVariable("evaluationId") Integer evaluationId) {
		
		Optional<EvaluationName> check_assignment=assignemntService.findByEvaluationId(evaluationId);
		if(check_assignment.isPresent()) {
			assignemntService.deleteAssignmentById(evaluationId);
		        return ResponseEntity.ok().build();
		}
		else {

	    	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	     
	}
	
	@GetMapping("/{evaluationId}")
	public ResponseEntity<Optional<EvaluationName>> getAssignmentByEvaluationId(@PathVariable("evaluationId") Integer evaluationId) {
		return ResponseEntity.ok(assignemntService.findByEvaluationId(evaluationId));
	}
	
	
	
}
