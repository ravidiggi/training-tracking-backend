package com.cozentus.trainingtracking.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "batch_program_course_teacher")
public class BatchProgramCourseTeacher {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "batch_program_course_teacher_id")
	private Integer batchProgramCourseTeacherId;

	@Column(name = "batch_id", nullable = true)
	private Integer batchId;

	@Column(name = "program_id", nullable = true)
	private Integer programId;

	@Column(name = "course_id", nullable = true)
	private Integer courseId;

	@Column(name = "teacher_id", nullable = true)
	private Integer teacherId;

	public BatchProgramCourseTeacher(Integer batchProgramCourseTeacherId, Integer batchId, Integer programId,
			Integer courseId, Integer teacherId) {
		super();
		this.batchProgramCourseTeacherId = batchProgramCourseTeacherId;
		this.batchId = batchId;
		this.programId = programId;
		this.courseId = courseId;
		this.teacherId = teacherId;
	}

	public BatchProgramCourseTeacher() {
	}

	public Integer getBatchProgramCourseTeacherId() {
		return batchProgramCourseTeacherId;
	}

	public void setBatchProgramCourseTeacherId(Integer batchProgramCourseTeacherId) {
		this.batchProgramCourseTeacherId = batchProgramCourseTeacherId;
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public Integer getProgramId() {
		return programId;
	}

	public void setProgramId(Integer programId) {
		this.programId = programId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public Integer getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}

	@Override
	public String toString() {
		return "BatchProgramCourseTeacher [batchProgramCourseTeacherId=" + batchProgramCourseTeacherId + ", batchId="
				+ batchId + ", programId=" + programId + ", courseId=" + courseId + ", teacherId=" + teacherId + "]";
	}

}
