package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.repository.CourseRepository;


@Service
public class CourseService {
	
	@Autowired
	private CourseRepository courseRepository;
	
	public List<Course> listOfCourses()
	{
		List<Course> program = (List<Course>) this.courseRepository.findAll();
		
		return program;
	}
	
	public List<Course> getAllCourses() {
		return courseRepository.findAll();
	}

	public Course addCourse(Course course) {
		return courseRepository.save(course);
	}
	
	public Optional<Course> findCourseById(Integer id)
	{
		Optional<Course> course=null;
		course = courseRepository.findById(id);
		return course;
	}
	
	public Course saveCourse(Course course)
	{
		return courseRepository.save(course);
	}
	
//	update table where id=?
	public Course updateCourse(Course course,Integer id)
	{
		course.setCourseId(id);
		return courseRepository.save(course);
	}
	
	public void deleteCourseById(Integer id)
	{
		courseRepository.deleteById(id);
	}
	
	public List<Course> getCoursesByProgramId(Integer id) {
		return courseRepository.findByProgramId(id);
	}
	
	public List<Course> getCoursesByProgramIdAndBatchId(Integer programId, Integer batchId) {
		return courseRepository.findByProgramIdAndBatchId(programId, batchId);
	}
}
