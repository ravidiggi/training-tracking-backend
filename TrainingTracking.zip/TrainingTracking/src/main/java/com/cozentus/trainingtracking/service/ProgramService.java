package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Program;
import com.cozentus.trainingtracking.repository.ProgramRepository;

@Service
public class ProgramService {

	@Autowired
	private ProgramRepository programRepository;

	public List<Program> listOfPrograms() {
		List<Program> program = (List<Program>) this.programRepository.findAll();

		return program;
	}
	

	public List<Program> getAllPrograms() {
		return (List<Program>) programRepository.findAll();
	}
	
	public Optional<Program> findProgramById(Integer id) {
		Optional<Program> program = null;
		program = programRepository.findById(id);
		return program;
	}

	
	public Program updateProgram(Program program, Integer id) {
		program.setProgramId(id);
		return programRepository.save(program);
	}

	public void deleteProgramById(Integer id) {
		programRepository.deleteById(id);
	}
	
	

	public Program addProgram(Program program) {
		return programRepository.save(program);
	}

	

	

	public Optional<Program> getProgramById(int id) {
		return programRepository.findById(id);
	}

	
}
