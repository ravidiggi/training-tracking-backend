package com.cozentus.trainingtracking.utillity;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FileUploadUtility {

	public final String ABS_PATH = "D:\\cozentus\\CozentusApp workspace\\ProjectExec\\src\\main\\resources\\static\\Uploads\\";

	public FileUploadUtility() {
	}

	boolean fileUpload = false;

	public boolean uploadFile(MultipartFile file) {
		try {
			Files.copy(file.getInputStream(), Paths.get(ABS_PATH + file.getOriginalFilename()),
					StandardCopyOption.REPLACE_EXISTING);
			fileUpload = true;
		} catch (Exception e) {
		}
		return fileUpload;
	}

}
