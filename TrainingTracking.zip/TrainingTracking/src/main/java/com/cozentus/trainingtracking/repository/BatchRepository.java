package com.cozentus.trainingtracking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cozentus.trainingtracking.model.Batch;


public interface BatchRepository extends JpaRepository<Batch, Integer> {
	List<Batch> findByProgramId(int programId);

	@Modifying
	@Query("UPDATE Batch SET programId=:programId where batchId=:batchId")
	void updateProgramIdOfBatch(@Param("batchId") Integer batchId, @Param("programId") Integer programId);

	@Query(value = "SELECT * FROM batch b LEFT JOIN program p ON p.program_id = b.program_id "
			+ "LEFT JOIN course c ON c.program_id = p.program_id " + "LEFT JOIN student s ON b.batch_id = s.batch_id "
			+ "UNION " + "SELECT * FROM batch b RIGHT JOIN program p ON p.program_id = b.program_id "
			+ "RIGHT JOIN course c ON c.program_id = p.program_id "
			+ "RIGHT JOIN student s ON b.batch_id = s.batch_id ", nativeQuery = true)
	List<Object[]> getFullJoinData();
}