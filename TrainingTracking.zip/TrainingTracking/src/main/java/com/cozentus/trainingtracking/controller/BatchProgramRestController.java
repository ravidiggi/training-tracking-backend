package com.cozentus.trainingtracking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Batch;
import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.model.Program;
import com.cozentus.trainingtracking.model.Topic;
import com.cozentus.trainingtracking.service.BatchService;
import com.cozentus.trainingtracking.service.CourseService;
import com.cozentus.trainingtracking.service.ProgramService;
import com.cozentus.trainingtracking.service.TopicService;

@RestController
@RequestMapping("/batch-program")
@PreAuthorize("hasAuthority('ROLE_TEACHER')")
public class BatchProgramRestController {

	@Autowired
	private BatchService batchService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private ProgramService programService;
	
	
	@Autowired
	private TopicService topicService;
	

	@GetMapping("/batch/show/all")
	public ResponseEntity<List<Batch>> getAllBatches() {
		return ResponseEntity.ok(batchService.getAllBatches());
	}

	@GetMapping("/program/show/all")
	public ResponseEntity<List<Program>> getAllPrograms() {
		return ResponseEntity.ok(programService.getAllPrograms());
	}

	@GetMapping("/course/show/all")
	public ResponseEntity<List<Course>> getAllCourses() {
		return ResponseEntity.ok(courseService.getAllCourses());
	}
	
	@GetMapping("/topic/show/all")
	public List<Topic> getAllTopics() {
		return topicService.getAllTopics();
	}
	
	@GetMapping("/x")
	public List<Object[]> getFullJoinData() {
		return batchService.getFullJoinData();
	}
}
