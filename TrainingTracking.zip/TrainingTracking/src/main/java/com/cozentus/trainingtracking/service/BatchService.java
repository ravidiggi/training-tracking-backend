package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Batch;
import com.cozentus.trainingtracking.model.Student;
import com.cozentus.trainingtracking.repository.BatchRepository;
import com.cozentus.trainingtracking.repository.StudentRepository;

@Service
public class BatchService {
	@Autowired
	private BatchRepository batchRepository;

	@Autowired
	private StudentRepository studentRepository;

	public List<Batch> getAllBatches() {
		return batchRepository.findAll();
	}

	public Optional<Batch> getBatchById(int id) {
		return batchRepository.findById(id);
	}

	public Batch addBatch(Batch batch) {
		return batchRepository.save(batch);
	}

	public Batch updateBatch(Batch batch, int id) {
		batch.setBatchId(id);
		return batchRepository.save(batch);
	}

	public void deleteBatchById(int id) {
		batchRepository.deleteById(id);
	}

	public List<Batch> getBatchesByProgramId(int programId) {
		return batchRepository.findByProgramId(programId);
	}

	public List<Student> getStudentsByProgramId(int programId) {
		return studentRepository.findByProgramId(programId);
	}

	public List<Student> getStudentsByBatchIdAndProgramId(Integer batchId, Integer programId) {
		return studentRepository.getStudentsByBatchIdAndProgramId(batchId, programId);
	}

	public void updateProgramIdOfBatch(Integer batchId, Integer programId) {

		batchRepository.updateProgramIdOfBatch(batchId, programId);
	}
	
	public List<Object[]> getFullJoinData() {
		return batchRepository.getFullJoinData();
	}
}