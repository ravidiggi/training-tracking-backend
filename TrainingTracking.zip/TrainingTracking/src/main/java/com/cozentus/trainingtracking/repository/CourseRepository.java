package com.cozentus.trainingtracking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cozentus.trainingtracking.model.Course;


public interface CourseRepository extends JpaRepository<Course, Integer> {
	
	List<Course> findByProgramId(Integer programId);
	
	@Modifying
	@Query("UPDATE Course SET programId=:programId where courseId=:courseId")
	void updateCourseProgramId(Integer courseId, Integer programId);

	@Query("FROM Course c JOIN Batch b ON c.programId = b.programId WHERE c.programId = :programId AND b.batchId = :batchId")
	List<Course> findByProgramIdAndBatchId(@Param("programId") Integer programId, @Param("batchId") Integer batchId);

}