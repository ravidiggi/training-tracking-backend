package com.cozentus.trainingtracking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.TeacherCourse;
import com.cozentus.trainingtracking.repository.TeacherCourseRepository;

@Service
public class TeacherCourseService {
	@Autowired
	private TeacherCourseRepository teacherCourseRepository;
	
	void addTeacherCourse(Integer teacherId, List<Integer> courseIds) {
		TeacherCourse teacherCourse = new TeacherCourse();
		teacherCourse.setTeacherId(teacherId);
		
		for(Integer couseId : courseIds) {
			teacherCourse.setCourseId(couseId);
			teacherCourseRepository.save(teacherCourse);
		}
	}
}
