package com.cozentus.trainingtracking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cozentus.trainingtracking.model.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Integer>{
	List<Teacher> findByCourseId(int courseId);

	@Query("FROM Teacher t JOIN Course c JOIN Program p JOIN Batch b WHERE b.batchId = :batchId AND p.programId = :programId AND c.courseId = :courseId")
	List<Teacher> findByCourseIdProgramIdAndBatchId(@Param("courseId") Integer courseId,
			@Param("programId") Integer programId, @Param("batchId") Integer batchId);
}