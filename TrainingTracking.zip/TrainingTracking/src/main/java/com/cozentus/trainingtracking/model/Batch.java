package com.cozentus.trainingtracking.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "batch")
public class Batch {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "batch_id")
	private Integer batchId;

	@Column(name = "batch_code")
	private String batchCode;

	@Column(name = "program_id")
	private Integer programId;

	@Column(name = "batch_name")
	private String batchName;

	@Column(name = "batch_startdate")
	private Date batchStartdate;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "updated_by")
	private String updatedBy;

	public Batch(Integer batchId, String batchCode, Integer programId, String batchName, Date batchStartdate, Date createdDate,
			String createdBy, Date modifiedDate, String updatedBy) {
		this.batchId = batchId;
		this.batchCode = batchCode;
		this.programId = programId;
		this.batchName = batchName;
		this.batchStartdate = batchStartdate;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.updatedBy = updatedBy;
	}

	public Batch() {
	}

	public Integer getBatchId() {
		return batchId;
	}

	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}

	public String getBatchCode() {
		return batchCode;
	}

	public void setBatchCode(String batchCode) {
		this.batchCode = batchCode;
	}

	public Integer getProgramId() {
		return programId;
	}

	public void setProgramId(Integer programId) {
		this.programId = programId;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public Date getBatchStartdate() {
		return batchStartdate;
	}

	public void setBatchStartdate(Date batchStartdate) {
		this.batchStartdate = batchStartdate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "Batch [batchId=" + batchId + ", batchCode=" + batchCode + ", programId=" + programId + ", batchName="
				+ batchName + ", batchStartdate=" + batchStartdate + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + ", updatedBy=" + updatedBy + "]";
	}
}
