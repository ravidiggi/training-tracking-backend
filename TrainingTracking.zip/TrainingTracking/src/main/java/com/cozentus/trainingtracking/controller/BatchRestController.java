package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Batch;
import com.cozentus.trainingtracking.model.Program;
import com.cozentus.trainingtracking.service.BatchService;
import com.cozentus.trainingtracking.service.CourseService;
import com.cozentus.trainingtracking.service.ProgramService;
import com.cozentus.trainingtracking.service.StudentService;
import com.cozentus.trainingtracking.service.TeacherService;

import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/batch")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class BatchRestController {
	
	@Autowired
	private BatchService batchService;
	
	@Autowired
	private CourseService courseService;

	@Autowired
	private ProgramService programService;

	@Autowired
	private TeacherService teacherService;

	@Autowired
	private StudentService studentService;

	@GetMapping("/show/all")
	public ResponseEntity<List<Batch>> getAllBatches() {
		return ResponseEntity.ok(batchService.getAllBatches());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Batch>> getBatchById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(batchService.getBatchById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Batch> addBatch(@RequestBody Batch program) {
		return ResponseEntity.ok(batchService.addBatch(program));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Batch> updateBatch(@RequestBody Batch program, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(batchService.updateBatch(program, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteBatchById(@RequestBody Program program, @PathVariable("id") Integer id) {
		batchService.deleteBatchById(id);
		return ResponseEntity.ok().build();
	}
	
	@GetMapping("/program/{id}")
	public ResponseEntity<List<Batch>> getBatchesByProgramId(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(batchService.getBatchesByProgramId(id));
	}
	
	@Transactional
	@PutMapping("/update/student/batch/{batchId}")
	public ResponseEntity<Void> updateBatchIdOfStudent(@RequestBody List<Integer> studentsId ,@PathVariable("batchId") Integer batchId){
		 studentService.updateBatchIdofStudent(studentsId,batchId);
		 return ResponseEntity.ok().build();
	}
}
