package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.model.EvaluationName;
import com.cozentus.trainingtracking.model.Topic;
import com.cozentus.trainingtracking.repository.AssignmentRepository;


@Service
public class AssignmentService {

	@Autowired
	private AssignmentRepository assignmentRepository;

	@Autowired
	private CourseService courseService;

	@Autowired
	private TopicService topicService;

	public List<EvaluationName> listOfAssignments() {
		List<EvaluationName> assignment_list = (List<EvaluationName>) this.assignmentRepository.findAll();
		return assignment_list;

	}

	public EvaluationName addAssignment(EvaluationName evaluationName) {
		evaluationName.setType("Assignment");
		return assignmentRepository.save(evaluationName);

	}

	public EvaluationName updateAssignment(EvaluationName evaluationName, Integer evaluationId) {
		evaluationName.setEvaluationId(evaluationId);
		return assignmentRepository.save(evaluationName);
	}

	public void deleteAssignmentById(Integer evaluationId) {
		assignmentRepository.deleteById(evaluationId);
	}

	public Optional<EvaluationName> findByEvaluationId(Integer evaluationId) {
		Optional<EvaluationName> evaluationName = assignmentRepository.findById(evaluationId);
		return evaluationName;
	}

	@GetMapping("/all-courses/{programId}")
	public ResponseEntity<List<Course>> getCoursesByProgramId(@PathVariable("programId") Integer programId) {
		return ResponseEntity.ok(courseService.getCoursesByProgramId(programId));
	}

	@GetMapping("/all-topics/{courseId}")
	public ResponseEntity<List<Topic>> getTopicsByCourseId(@PathVariable("courseId") Integer courseId) {
		return ResponseEntity.ok(topicService.getTopicByCourseId(courseId));
	}

}
