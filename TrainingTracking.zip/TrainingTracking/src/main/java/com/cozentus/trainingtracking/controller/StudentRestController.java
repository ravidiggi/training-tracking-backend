package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Student;
import com.cozentus.trainingtracking.service.CredentialService;
import com.cozentus.trainingtracking.service.StudentService;

@RestController
@RequestMapping("/student")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class StudentRestController {
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private CredentialService credentialService;

	@GetMapping("/show/all")
	public ResponseEntity<List<Student>> getAllStudents() {
		return ResponseEntity.ok(studentService.listOfStudents());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Student>> getStudentById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(studentService.getStudentById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Student> addStudent(@RequestBody Student student) {
		credentialService.addStudentCredential(student);
		return ResponseEntity.ok(studentService.addStudent(student));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(studentService.updateStudent(student, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteStudentById(@PathVariable("id") Integer id) {
		studentService.deleteStudent(id);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/program/{programId}")
	public ResponseEntity<List<Student>> getStudentsByProgramId(@PathVariable("programId") Integer programId) {
		return ResponseEntity.ok(studentService.getStudentByProgramId(programId));
	}

	@GetMapping("/batch/{batchId}")
	public ResponseEntity<List<Student>> getStudentsByBatchId(@PathVariable("batchId") Integer batchId) {
		return ResponseEntity.ok(studentService.getStudentByBatchId(batchId));
	}

}
