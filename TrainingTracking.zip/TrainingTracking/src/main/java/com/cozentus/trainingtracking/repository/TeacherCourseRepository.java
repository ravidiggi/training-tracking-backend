package com.cozentus.trainingtracking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cozentus.trainingtracking.model.TeacherCourse;

public interface TeacherCourseRepository extends JpaRepository<TeacherCourse, Integer> {
}
