package com.cozentus.trainingtracking.controller;



import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Attendance;
import com.cozentus.trainingtracking.model.Course;
import com.cozentus.trainingtracking.model.Topic;
import com.cozentus.trainingtracking.service.AttendanceService;
import com.cozentus.trainingtracking.service.CourseService;
import com.cozentus.trainingtracking.service.TopicService;


@RestController
@RequestMapping("/attendance")
@PreAuthorize("hasAuthority('ROLE_TEACHER')")
public class AttendanceRestController {

	@Autowired
	private AttendanceService attendanceService;

	@Autowired
	private CourseService courseService;

	@Autowired
	private TopicService topicService;

	@GetMapping("/all-attendances")
	public ResponseEntity<List<Attendance>> getAllAttendances() {
		List<Attendance> all_attendances = attendanceService.listOfAttendances();
		return ResponseEntity.ok(all_attendances);

	}

	@PostMapping("/add-attendance")
	public ResponseEntity<Attendance> addAttendances(@RequestBody Attendance attendance) {
		Attendance added_attendance = attendanceService.addAttendance(attendance);

		return ResponseEntity.ok(added_attendance);
	}

	@PutMapping("/update-attendance/{attendanceId}")
	public ResponseEntity<Attendance> updateAttendances(@RequestBody Attendance attendance,
			@PathVariable("attendanceId") Integer attendanceId) {
		Attendance updated_attendance = attendanceService.updateAttendance(attendance, attendanceId);
		return ResponseEntity.ok(updated_attendance);

	}

	@DeleteMapping("/delete-attendance/{attendanceId}")

	public ResponseEntity<Void> deleteAttendanceByIds(@PathVariable("attendanceId") Integer attendanceId) {

		Optional<Attendance> check_attendance = attendanceService.findByAttendanceId(attendanceId);
		if (check_attendance.isPresent()) {
			attendanceService.deleteAttendanceById(attendanceId);
			return ResponseEntity.ok().build();
		} else {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

	}

	@GetMapping("/{attendanceId}")
	public ResponseEntity<Optional<Attendance>> getByAttendanceId(@PathVariable("attendanceId") Integer attendanceId) {
		return ResponseEntity.ok(attendanceService.findByAttendanceId(attendanceId));
	}

	@GetMapping("/all-courses/{programId}")
	public ResponseEntity<List<Course>> getCoursesByProgramId(@PathVariable("programId") Integer programId) {
		return ResponseEntity.ok(courseService.getCoursesByProgramId(programId));
	}

	@GetMapping("/all-topics/{courseId}")
	public ResponseEntity<List<Topic>> getTopicsByCourseId(@PathVariable("courseId") Integer courseId) {
		return ResponseEntity.ok(topicService.getTopicByCourseId(courseId));
	}

	@PostMapping("/update/topic/{topicId}")
	public ResponseEntity<Void> updateTopicPercentage(@RequestBody Integer topicPercentage,
			@PathVariable("topicId") Integer topicId) {
		topicService.updateTopicPercentageCompleted(topicPercentage, topicId);
		return ResponseEntity.ok().build();
	}

	@PostMapping("/add-attendances")
	public ResponseEntity<Void> addAttendances(@RequestBody List<Attendance> attendances) {
		attendanceService.addAttendances(attendances);
		
		return ResponseEntity.ok().build();
	}
	
	
	@Transactional
	@PostMapping("/update-attendances")
	public ResponseEntity<Void> updateAttendances(@RequestBody List<Attendance> attendances) {
		attendanceService.updateAttendances(attendances);
		
		return ResponseEntity.ok().build();
	}
}
