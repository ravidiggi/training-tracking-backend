package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Teacher;
import com.cozentus.trainingtracking.service.CredentialService;
import com.cozentus.trainingtracking.service.TeacherService;

@RestController
@RequestMapping("/teacher")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class TeacherRestController {
	@Autowired
	private TeacherService teacherService;

	@Autowired
	private CredentialService credentialService;

	@GetMapping("/show/all")
	public ResponseEntity<List<Teacher>> getAllTeachers() {
		return ResponseEntity.ok(teacherService.getAllTeachers());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Teacher>> getTeacherById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(teacherService.getTeacherById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Teacher> addTeacher(@RequestBody Teacher teacher) {
		credentialService.addTeacherCredential(teacher);
		return ResponseEntity.ok(teacherService.addTeacher(teacher));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Teacher> updateTeacher(@RequestBody Teacher teacher, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(teacherService.updateTeacher(teacher, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteTeacherById(@PathVariable("id") Integer id) {
		teacherService.deleteTeacherById(id);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/course/{courseId}")
	public ResponseEntity<List<Teacher>> getTeachersByCourseId(@PathVariable("courseId") Integer courseId) {
		return ResponseEntity.ok(teacherService.getTeachersByCourseId(courseId));
	}
}
