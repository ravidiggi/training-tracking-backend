package com.cozentus.trainingtracking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cozentus.trainingtracking.model.Program;
import com.cozentus.trainingtracking.service.ProgramService;

@RestController
@RequestMapping("/program")
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class ProgramRestController {
	
	@Autowired
	private ProgramService programService;

	@GetMapping("/show/all")
	public ResponseEntity<List<Program>> getAllPrograms() {
		return ResponseEntity.ok(programService.listOfPrograms());
	}

	@GetMapping("/show/{id}")
	public ResponseEntity<Optional<Program>> getProgramById(@PathVariable("id") Integer id) {
		return ResponseEntity.ok(programService.findProgramById(id));
	}

	@PostMapping("/add")
	public ResponseEntity<Program> addProgram(@RequestBody Program program) {
		return ResponseEntity.ok(programService.addProgram(program));
	}

	@PostMapping("/update/{id}")
	public ResponseEntity<Program> updateProgram(@RequestBody Program program, @PathVariable("id") Integer id) {
		return ResponseEntity.ok(programService.updateProgram(program, id));
	}

	@PostMapping("/delete/{id}")
	public ResponseEntity<Void> deleteProgramById(@RequestBody Program program, @PathVariable("id") Integer id) {
		programService.deleteProgramById(id);
		return ResponseEntity.ok().build();
	}
}
