package com.cozentus.trainingtracking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cozentus.trainingtracking.model.Topic;
import com.cozentus.trainingtracking.repository.TopicRepository;

@Service
public class TopicService {
	
	@Autowired
	private TopicRepository topicRepository;
	
	
	public Optional<Topic> getTopicById(Integer topicId) {
		return topicRepository.findById(topicId);
	}
	
	public List<Topic> getAllTopics() {
		return topicRepository.findAll();
	}
	
	public Topic addTopic(Topic topic) {
		return topicRepository.save(topic);
	}
	
	public Topic updateTopic(Topic topic, Integer id) {
		topic.setTopicId(id);
		return topicRepository.save(topic);
	}
	public void deleteTopic(Integer id) {
		topicRepository.deleteById(id);
	}
	
	public List<Topic> getTopicByCourseId(Integer id) {
		return topicRepository.findByCourseId(id);
	}

		public void updateTopicPercentageCompleted(int topicPercentage, int topicId) {
		topicRepository.updateTopicPercentageCompleted(topicPercentage, topicId);
	}

}
